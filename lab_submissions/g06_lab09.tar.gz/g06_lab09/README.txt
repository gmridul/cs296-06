CS 296- Assignment 9
Group no. 06
Sagar Jha - 110100024
Sudipto Biswas - 110050048
Mridul Garg - 110050030

All the submitted work is our own and we have not copied it from anywhere.

Please note that to automate the loading of images into the html file, we have changed the variable names of the image files in the tex file from plot1 to plot01 and so on.
