#! /bin/bash

mkdir -p $1/backup
cp -u -r -b src $1/backup
