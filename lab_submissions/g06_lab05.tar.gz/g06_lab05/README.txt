To build the base code do the following:

1. Go into the external/src folder and read the README there to build Box2D first.

2. Return back to the cs296_base_code folder and type 'make' to compile.

3. Type 'bin/cs296_base' to run the program.

